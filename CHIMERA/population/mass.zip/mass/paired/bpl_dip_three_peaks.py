import jax.numpy as jnp
from plum import dispatch

from .base import base_mass_paired_struct, mass_pdf_notnorm, pairing_function
from ..core import tpl_notnorm, tpl_cdf, truncated_gaussian, high_pass_filter


class bpl_dip_three_peaks(base_mass_paired_struct):

  alpha_1: float
  beta_1: float
  alpha_2: float
  b: float  
  beta_2: float
  mu_g1: float
  sigma_g1: float
  mu_g2: float
  sigma_g2: float
  mu_g2: float
  sigma_g2: float
  mu_g3: float
  sigma_g3: float
  lambda_g: float
  lambda_1: float
  lambda_2: float
  delta_m_min: float
  delta_m_max: float
  m_d_low: float
  m_d_high: float
  delta_d_min: float
  delta_d_max: float

  default = {
    **base_mass_paired_struct.default,
    'm_low': ,
    'm_high': ,
    'alpha_1':       3.6,
    'beta_1':        1.08,
    'alpha_2':       3.6,
    'beta_2':        1.08,
    'mu_g1':       28.6,
    'sigma_g1':     5.15,
    'mu_g2':       28.6,
    'sigma_g2':     5.15,
    'mu_g2':       28.6,
    'sigma_g2':     5.15,
    'mu_g3':       28.6,
    'sigma_g3':     5.15,
    'lambda_g': ,
    'lambda_1': ,
    'lambda_2': ,
    'delta_m_min':     3.3,
    'delta_m_max':     3.3,
    'm_d_low':
    'm_d_high':
    'delta_d_min':     3.3,
    'delta_d_max':     3.3,
  }
  name = 'paired_broken_triple_peak_dip'


# ---------------------------------------------------------------------------
# Marginal shape (same for m1 and m2)
# ---------------------------------------------------------------------------

@dispatch
def mass_pdf_notnorm(mass: plp, m: jnp.ndarray) -> jnp.ndarray:
  """p̃(m) = [(1-λ_g) BPL(m) + λ_g λ_1 G_1(m) + λ_g (1 - λ_1) λ_2 G_2(m) + λ_g (1 - λ_1) (1-λ_2) G_3(m)] * S(m).

  The power-law component is internally normalised (divided by its own CDF
  at m_high) so that the mixing fraction λ_peak is meaningful before the
  final 2-D normalisation Z is applied.
  """
  # Normalised truncated power law
  P = tpl_notnorm(m, -mass.alpha, mass.m_low, mass.m_high) / tpl_cdf(mass.m_high, -mass.alpha, mass.m_low)

  # Truncated Gaussian peak (truncated between m_low and μ + 5σ for speed)
  G = truncated_gaussian(m, mass.mu_g, mass.sigma_g, mass.m_low, mass.mu_g + 5.0 * mass.sigma_g)

  pdf = (1.0 - mass.lambda_peak) * P + mass.lambda_peak * G
  pdf *= smoothing(m, mass.delta_m, mass.m_low)
  return pdf


# ---------------------------------------------------------------------------
# Pairing function  f(m1, m2) = q^β,  q = m2/m1,  for q <= 1
# ---------------------------------------------------------------------------

@dispatch
def pairing_function(mass: plp,
                     m1: jnp.ndarray,
                     m2: jnp.ndarray) -> jnp.ndarray:
  """f(m1, m2) = (m2/m1)^β  for m2 <= m1, else 0.

  The power-law index β encodes the preference for equal-mass (β > 0) or
  unequal-mass (β < 0) binaries.  β = 0 gives a flat mass-ratio distribution.
  """
  q = m2 / m1
  return jnp.where(q <= 1.0, jnp.power(q, mass.beta), 0.0)
